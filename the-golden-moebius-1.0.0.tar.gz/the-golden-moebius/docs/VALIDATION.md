# Validation — 24 October 2026

## Completed

- JavaScript syntax checks for homepage behavior, shared subpage controls, game modules, and both inline application scripts.
- Static inspection of all seven HTML documents, 89 local links/assets/fragments, stylesheet URLs and the locally bundled Three.js import map. No CDN runtime scripts, remote font stylesheets or hotlinked images remain.
- **Gold Rush:** 35 automated scenarios covering startup, checkout, all eleven events with/without supplies, lethal event damage, preservation of game-over screens and fresh expeditions after retry. Browser checks covered setup, purchasing and the trail screen with the local pixel font and compiled utility CSS.
- **West Bank:** 13 Node test groups, including twelve full deterministic runs across three modes and four seeds: 216 shifts and 648 duel opponents. Browser checks covered the embedded game, starting play and real deposit progress.
- **Installer:** 20 Python test groups covering Caddy/Nginx configuration parsing, host isolation, TLS/auth preservation, import handling, refusal of ambiguous/shared configurations, archive path/link/checksum defenses, successful release installation and rollback after a simulated reload failure. Transaction tests use temporary files and mocked service commands; they do not contact NYC1.
- **Gold shader:** compiled and linked using Mesa software OpenGL, with three rendered animation phases and a visible warm-gold surface. This validates shader structure/rendering outside the browser.
- **Browser:** homepage imagery/layout, mathematical ribbon drawing, edge-trace controls, source links opening the references, shared viewer route and the viewer's no-WebGL fallback. A 390-pixel iframe was used to inspect the narrow-screen homepage layout.

## Boundaries

- The cloud browser has no usable WebGL context. Hardware-accelerated interactive 3D was not exercised in that browser. The existing viewer controls and rendering loop are retained, with a visible still-image fallback and disabled motion controls if initialization fails.
- The remote browser throttles animation between tool interactions; it is not a human timing/playability benchmark. Actual touch latency, audio timbre and human difficulty balance remain device-dependent playtesting items.
- NYC1 was not reached: `ssh nyc1` failed because the build workspace has no configured SSH alias/address for it. No remote files, DNS records, Cloudflare settings or web-server configuration were changed.
- The actual NYC1 virtual-host layout, TLS configuration, OS permissions and reload behavior have not been inspected or validated. The installer checks these on the destination and stops on unsupported layouts. Native Caddy/Nginx validation happens there before reloading.
- PowerShell was unavailable in the build environment, so `Deploy.ps1` was reviewed but not executed. Its generated Python installer and payload validation/rollback paths were tested separately.

## Reproduce

```text
python3 checks/check_site.py
node --check dist/assets/home.js
node --check dist/assets/experience.js
node --test checks/engine.test.mjs
node checks/check-goldrush.cjs dist/gold-rush/play.html
python3 checks/test_deploy.py
```

For Windows, substitute the `py` launcher for `python3`. The three-phase shader check used a temporary ModernGL 5.12.0 / glcontext 3.0.0 installation, Mesa llvmpipe, NumPy and Pillow; these are QA tools and are not dependencies of the shipped site.
