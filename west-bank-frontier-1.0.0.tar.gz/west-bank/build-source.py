"""Build a portable source archive, excluding generated archives and hosting ID."""
from __future__ import annotations

import gzip
import io
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "dist" / "west-bank-source.tar.gz"
FILES = [
    "README.md", "package.json", "serve.ps1", "serve.sh", "build-source.py",
    "docs/DESIGN.md", "docs/VALIDATION.md", "tests/engine.test.js",
    "dist/index.html", "dist/style.css", "dist/engine.js", "dist/game.js", "dist/favicon.svg",
]

def main() -> None:
    stream = io.BytesIO()
    with tarfile.open(fileobj=stream, mode="w", format=tarfile.PAX_FORMAT) as archive:
        for name in FILES:
            content = (ROOT / name).read_bytes()
            info = tarfile.TarInfo("west-bank/" + name)
            info.size = len(content)
            info.mode = 0o755 if name.endswith(".sh") else 0o644
            info.mtime = 0
            archive.addfile(info, io.BytesIO(content))
    with OUTPUT.open("wb") as raw, gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as compressed:
        compressed.write(stream.getvalue())
    print(f"Created {OUTPUT} ({OUTPUT.stat().st_size:,} bytes)")

if __name__ == "__main__":
    main()
