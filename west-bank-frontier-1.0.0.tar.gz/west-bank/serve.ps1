param([ValidateRange(1024,65535)][int]$Port = 8080)
$ErrorActionPreference = 'Stop'
$ContentDirectory = Join-Path $PSScriptRoot 'dist'
if (Get-Command py -ErrorAction SilentlyContinue) {
    Write-Host "West Bank: http://127.0.0.1:$Port — Ctrl+C to stop"
    & py -m http.server $Port --bind 127.0.0.1 --directory $ContentDirectory
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
    Write-Host "West Bank: http://127.0.0.1:$Port — Ctrl+C to stop"
    & python -m http.server $Port --bind 127.0.0.1 --directory $ContentDirectory
} else {
    throw 'Python 3 was not found. Install it from python.org, or upload dist/ to a static web host.'
}
exit $LASTEXITCODE
