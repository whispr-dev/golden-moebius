#!/bin/sh
set -eu
project_directory=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
port=${1:-8080}
printf 'West Bank: http://127.0.0.1:%s — Ctrl+C to stop\n' "$port"
exec python3 -m http.server "$port" --bind 127.0.0.1 --directory "$project_directory/dist"
