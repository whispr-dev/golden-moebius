# Validation record

Validated on 24 October 2026 with Node.js 24.22.1 and the managed Chromium browser.

## Automated simulation

`npm test` runs 13 Node test groups, without third-party packages. Coverage includes deterministic schedules, fixed steps, paused-state immutability, harmless deposits, innocent penalties, early-shot penalties, exact firing boundaries, immediate outlaws, hat removal, gold/bomb judgement, dandy outcomes, closed-door navigation, guaranteed deposits, completed-section quiet periods, duel recovery, timeout reset, terminal state immutability, invalid shot inputs and cooldowns.

The final test plays all eighteen shifts with a perfect deterministic bot, at all three difficulties and four seeds each: **216 shifts and 648 duel opponents**. It verifies victory, all stage transitions, reaction recording, positive scores and the five-life cap. It is a reachability/regression check, not a claim of human difficulty balance.

`npm run check` validates syntax for both shipped JavaScript modules.

## Browser checks

The page and Canvas bank rendered successfully. Start, keyboard section movement, customer auto-deposits, explicit pause/resume, sound toggle and page controls were exercised. Browser console inspection showed no application-source errors; unrelated browser-extension metadata errors were present. Narrow-width layout was inspected through a 390-pixel iframe. Files remain relative for subdirectory deployment.

The remote browser throttles animation between tool interactions. Initial overly aggressive stall auto-pausing was replaced with bounded catch-up: excess wall time is frozen, while each simulated step stays 20 ms. This prevented a pause/resume loop under throttling. Human reaction balance, audio timbre on real speakers, mobile device latency and full Safari/Firefox coverage remain unverified; do not interpret the automated perfect bot as a playtest of those properties.
