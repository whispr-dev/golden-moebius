# Implementation contract

## State and data flow

Input handlers enqueue commands. At each fixed 20 ms step, the renderer's loop drains that queue, applies commands, and calls `Game.tick()`. Rendering reads state and never mutates gameplay. Web Audio and DOM updates consume engine events. Their failures cannot affect enemy schedules.

Top-level states are `title`, `bank`, `duel`, `stageclear`, `gameover` and `victory`. `paused` is orthogonal. Only `bank` and `duel` advance time or accept shots. The initial title is rendered by the browser wrapper; `start()` resets the full run. Stage completion and run completion require explicit user acknowledgement before a new stage or run starts.

Door phases: `opening → waiting → armed → hit` for a waiting hostile; `opening → armed → hit` for an armed outlaw; `opening → waiting → closing` for a customer. `hit` and `closing` remove the encounter after their animation duration. Hats use `opening → waiting → reward → closing`. Every encounter is a plain object, and the seeded RNG is xorshift32.

## Engine interface

```js
import { Game, HZ, MODES, LAST_STAGE } from './dist/engine.js';
const events = [];
const game = new Game({ seed: 42, mode: 'classic', emit: e => events.push(e) });
game.start();
game.tick();       // one 20 ms step; no-op while paused or in a terminal state
game.shoot(0);     // 0 = left, 1 = centre, 2 = right; returns whether target hit
game.move(1);      // -1 = previous section, +1 = next; returns whether moved
game.paused = true;
```

`advance()` returns true only from `stageclear`. `beginDuel()` and `spawn()` are internal transition/test helpers; browser UI does not call them directly. Public browser input validates lanes through `shoot()`. Movement direction is generated from controlled +/-1 values, not untrusted input.

Event types: `message`, `move`, `door`, `deposit`, `shot`, `hat`, `hurt`, `draw`, `hit`, `duel`, `clear`, `end`. A message includes `message` and `kind`; door-related events include `lane`. The sink is synchronous. Supply a non-throwing `emit` handler.

## Invariants

- Exactly three visible lanes, nine deposit flags, and three sections.
- At most one encounter per visible lane. All three doors must close before movement.
- Shooting while paused, recovering, in a terminal state, during cooldown, or at an invalid lane cannot mutate score/lives.
- An armed hostile can be shot until its firing step; the UI drains inputs before ticking to preserve that boundary.
- Shooting a harmless person, an unarmed hostile or an exposed bomb loses one life. Recovery clears all concurrent threats.
- A completed section never schedules a new encounter; a completed ledger transitions only after all doors close.
- The score is a JavaScript number, not a signed 16-bit original-style accumulator. No deliberate original score overflow is reproduced.
- Art-only randomness does not consume the gameplay RNG. All audio noise is independently generated.

## Browser surface

No libraries, remote fonts, analytics, cookies, fetch/XHR, WebSockets, service workers or third-party assets. Local storage contains only `westbank.frontier.records.v1` and `westbank.frontier.muted.v1`. All storage parsing/writes are guarded; corrupt top-level score data is discarded. Browsers can deny storage without preventing play. Mute preference and high scores are device/origin-local; game progress is not persisted.

All inserted game messages use `textContent` or text nodes. There is no dynamic HTML interpolation. Controls are real buttons; pause/result overlays focus their primary action. The playfield has an accessible label and lives/messages are partly announced via a live region. This remains a visual reflex game; full nonvisual gameplay is not claimed. Reduced-motion preference removes scanlines, bobbing, shot stars and damage outlines; sound has an independent mute control.

## Intentional departures from the report

The browser is the runtime, not Python/Pygame. No CPU or AY register emulation is attempted: a PSG-inspired square/noise vocabulary is synthesized through Web Audio. Fixed simulation steps do not attempt to reproduce the CPC's clock cycles or prove its original interrupt timings. There are no traveling bullet sprites: lane shots resolve immediately against the exact encounter phase. Original instructions contradict the report's bomb rule; the exposed bomb must be left alone.

These choices keep installation unnecessary and the source small and self-contained. No original source, executable, art or timing traces were provided. Fidelity beyond the broad mechanics would require a separate reference capture/comparison pass against the desired original port.
