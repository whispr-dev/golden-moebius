# West Bank — Frontier Edition 1.0.0

A complete browser-native arcade game inspired by Dinamic Software's **West Bank**. Three visible doors, nine doors in total, two days of nine shifts, shoot-or-wait encounters, a five-hat bonus character, three-person duels, synthesized sound and local high scores. All artwork and sound in this project were created for this edition. No ROMs, extracted sprites, original soundtrack or dependencies are included.

This is a playable reinterpretation of the CPC-era game, not an emulator, disassembly port or verified frame-exact reproduction. The supplied Gemini report contained no working project. This implementation was built from scratch for the web.

## Play locally — Windows

With Python 3 installed, open PowerShell in this directory:

```powershell
py -m http.server 8080 --bind 127.0.0.1 --directory .\dist
Start-Process http://127.0.0.1:8080
```

Run the second command in another PowerShell tab, or open that URL yourself. Stop the server with Ctrl+C. No Python packages, Node install, npm install, build step or Internet access are needed to play. Use HTTP rather than double-clicking the HTML file: browsers restrict ES module imports under `file:` URLs.

Linux/macOS:

```sh
python3 -m http.server 8080 --bind 127.0.0.1 --directory ./dist
```

Open <http://127.0.0.1:8080> in a current browser supporting Canvas 2D and ES modules. Sound uses Web Audio and starts only after a user gesture. Fullscreen is optional and may be restricted by browser policy.

## Controls

| Action | Keyboard | Mouse / touch |
| --- | --- | --- |
| Shoot left / middle / right | 1 / 2 / 3 | Tap the corresponding door or fire button |
| Previous / next section | O / P, left / right arrows, A / D | Movement buttons |
| Pause / resume | Escape; Space when the canvas has focus | Pause / Back to the bank |
| Toggle sound | M | Sound button |
| Fullscreen | Browser-dependent | Fullscreen button |

Keyboard auto-repeat does not fire repeatedly. Each lane has a five-tick (100 ms) shot cooldown. Movement is possible only when every door is closed; it moves one three-door section at a time. Completing a section stops new appearances there, leaving a safe opportunity to move.

## Rules

Start with three lives. Lose a life for shooting an innocent customer, shooting an unarmed gunfighter, firing into a revealed bomb, running out of shift time, or allowing an armed enemy to fire. After a mistake, all doors close and an 85-tick recovery interval prevents overlapping losses.

- **Farmer and townsfolk:** leave them alone; their gold is automatically deposited.
- **Armed outlaw:** a raised pistol and `DRAW!` label mean shoot immediately.
- **Waiting gunfighter:** wait until the pistol is raised, then shoot.
- **Hat man (from shift 2):** shoot away five hats. Shoot the gold beneath for a deposit and bonus; leave a bomb untouched. The character eventually leaves if ignored, without a penalty.
- **Dandy (from shift 3):** may deposit or draw; judge the action, not the outfit.
- **Quickdraw (from shift 5):** a shorter reaction window.
- **Mystery visitor (from shift 6):** waits before drawing.

One deposit at every door completes the bank ledger and starts a duel. The three duellists raise their pistols in a shuffled order after the countdown. Only shoot a duellist whose pistol is already raised. Defeating all three grants $500 and one life, up to five lives. Losing a life during the duel restarts that duel without losing the bank deposits. Eighteen completed shifts finish the game. Shifts 8 and 9 of each day have a night palette.

Scores: ordinary deposits $100; each hat $10; hat gold $250; armed enemies $150 plus $10 per five ticks remaining in their reaction window; duel completion $500. Each accepted trigger pull counts toward accuracy; successful hits on hats, gold or armed enemies count as hits. Shots at empty, opening or closing doors count as misses but do not cost a life. Inputs during cooldown, pause or recovery are ignored.

## Difficulty and timing

The simulation runs in 20 ms steps (50 Hz). Rendering uses `requestAnimationFrame` and never directly advances the world. Commands are consumed before the next tick, so a shot immediately before an enemy deadline succeeds. Reaction times are quantized to 20 ms and have a 20 ms minimum.

| Mode | Shift limit | Initial ordinary armed window | Final ordinary armed window |
| --- | --- | --- | --- |
| Tenderfoot | 150 s | 70 ticks / 1,400 ms | 28 ticks / 560 ms |
| Deputy | 120 s | 48 ticks / 960 ms | 19 ticks / 380 ms |
| Gunslinger | 105 s | 36 ticks / 720 ms | 16 ticks / 320 ms |

Quickdraw windows subtract six ticks, with a floor of 16 ticks; duellists receive five extra ticks. Waiting duration and encounter scheduling are seeded pseudorandom choices, not authentic original tables. Customers are guaranteed within three visits to an unfilled door, so random selection cannot permanently prevent stage completion.

Leaving the tab or browser window pauses the game. Each rendered frame catches up at most five simulation ticks. During a long browser stall, excess wall time is frozen rather than fast-forwarded through an entire threat window; on severely throttled devices the game therefore slows down. This favors fair play over an unwinnable catch-up burst.

## Put it on any static website

Upload **the contents of `dist/`** into your chosen web directory, for example `/games/west-bank/`. Keep all files together. Asset paths are relative, so subdirectory hosting works without changes. Serve `.js` as JavaScript and `.css` as CSS; any ordinary static host, Caddy, Nginx, Apache or GitHub Pages can do this. There is no backend, API key, database or per-player server process.

Example iframe on another page:

```html
<iframe
  src="/games/west-bank/"
  title="West Bank — Frontier Edition"
  width="1280"
  height="1000"
  style="width:100%;border:0"
  allow="fullscreen"
  loading="lazy"
></iframe>
```

The full page includes the game and instructions. Prefer a direct page link if you want the browser to manage the page height naturally. High scores belong to the game's browser origin, not to an account, and are separate by difficulty. They do not migrate between origins or devices.

The downloadable `west-bank-source.tar.gz` is optional for gameplay; keep it if you want the source-download link in the footer to work. It intentionally excludes itself and hosting identity. `npm run check` and `npm test` require Node.js 22 or later and no installed packages. Node 24.22.1 was used for validation.

## Files and extension points

```text
west-bank/
  README.md
  package.json
  serve.ps1
  serve.sh
  build-source.py
  docs/
    DESIGN.md
    VALIDATION.md
  tests/
    engine.test.js
  dist/
    index.html
    style.css
    engine.js
    game.js
    favicon.svg
    west-bank-source.tar.gz
```

`engine.js` is the deterministic, DOM-free game. `game.js` handles input, original Canvas artwork, Web Audio, local storage and the fixed-step loop. Modify the engine first for new characters or rules; keep drawing and browser state out of it. Change the canvas renderer to adjust art without changing gameplay. `build-source.py` reproducibly packages the distributable source with the Python standard library.

## Attribution and publication scope

Original concept/game: **West Bank**, Dinamic Software; UK publishing associated with Gremlin Graphics. Historical gameplay reference: <https://retrogames.biz/games/c64/west-bank/>. That page describes the twelve-door version; this edition deliberately uses nine doors, informed by the CPC version. Different original ports have different details.

This edition uses its own code, art, interface, character drawings and synthesized effects. It does not claim official affiliation or reproduction accuracy. The original name and historical property remain associated with their respective owners; newly created assets do not establish permission to use third-party branding. No new third-party licensing grant is claimed here.

The initial hosted deployment is private. The static files can be moved to your own website without Sites tooling. Public sharing is a separate hosting/access decision.
